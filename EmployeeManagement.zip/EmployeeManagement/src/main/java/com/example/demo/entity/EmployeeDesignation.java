package com.example.demo.entity;

public enum EmployeeDesignation {
	DIRECTOR,
	MANAGER,
	EMPLOYEE
}
